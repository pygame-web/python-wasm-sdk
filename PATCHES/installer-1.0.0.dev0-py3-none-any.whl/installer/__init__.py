"""A library for installing Python wheels."""

__version__ = "1.0.0.dev0"
__all__ = ["install"]

from installer._core import install  # noqa
